package com.capgemini.core.pl;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.beans.Customer;
import com.capgemini.core.beans.Transactions;
import com.capgemini.core.beans.Wallet;
import com.capgemini.core.exceptions.InsufficientBalanceException;
import com.capgemini.core.exceptions.InvalidInputException;
import com.capgemini.core.service.WalletService;
import com.capgemini.core.service.WalletServiceImpl;

public class Client 
{
	WalletService service;
	
	Client() {
		System.out.println("Welcome to Payment Wallet Application");
		service = new WalletServiceImpl();
	}
	
	
	public void menu() {
		System.out.println("\n\n 1) Create New Paytm Account");
		System.out.println("2) Check Your Balance");
		System.out.println("3) Transfer Funds");
		System.out.println("4) Deposit Amount");
		System.out.println("5) Withdraw Funds");
		System.out.println("6) Print Transactions");
		System.out.println("0) Exit Application");
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your choice");
		int choice = sc.nextInt();

		String mobileNo;
		String mobileNo1;
		BigDecimal amount;
		String name;
		
		
		switch(choice) {
			case 1:
				Customer customer = new Customer();
				Wallet wallet = new Wallet();
				

				System.out.print("Enter Your Name          : ");
				name=sc.next();
				
				System.out.print("Enter Your Mobile Number : ");
				mobileNo=sc.next();
				
				System.out.print("Enter Balance            : ");
				amount=sc.nextBigDecimal();
				
				try 
				{
					customer = service.createAccount(name, mobileNo, amount);
					System.out.println("Thank you, "+customer.getName()+" Your Payment wallet account has been created successfully with Balance "+amount);
				
				} 
				catch (InvalidInputException e) {
					e.printStackTrace();
				}
				break;
				
			case 2:
				System.out.println("Enter mobile number");
				mobileNo = sc.next();
				
			try {
				customer = service.showBalance(mobileNo);
				System.out.print("The balance in account " + customer.getName() + " is " + customer.getWallet().getBalance());
				
			} catch (InvalidInputException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
				
				break;
			
			case 4:
				System.out.println("Enter mobile number");
				mobileNo = sc.next();
				
				System.out.println("Enter amount to be deposited");
				amount = sc.nextBigDecimal();
				
				try 
				{
					customer = service.depositAmount(mobileNo, amount);
					System.out.println("Successfully deposited");
					System.out.println("Account balance is: " + customer.getWallet().getBalance());
				} 
				catch (InvalidInputException e2) 
				{
					e2.printStackTrace();
				}
				
				
				
				break;
			
			case 5:
				System.out.println("Enter mobile number");
				mobileNo = sc.next();
				
				System.out.println("Enter amount to be withdrawn");
				amount = sc.nextBigDecimal();
				
				try 
				{
					customer = service.withdrawAmount(mobileNo, amount);
					System.out.println("Successfully withdrawn");
					System.out.println("Account balance is: " + customer.getWallet().getBalance());
				}
				catch (InvalidInputException e1) 
				{
					e1.printStackTrace();
				} catch (InsufficientBalanceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			
			case 3:
				System.out.print("Enter source mobile number: ");
				String sourceMobile = sc.next();
				
				System.out.print("Enter target mobile number: ");
				String targetMobile = sc.next();
				
				System.out.println("Enter amount to be transferred");
				amount = sc.nextBigDecimal();
				
				try 
				{
					customer = service.fundTransfer(sourceMobile, targetMobile, amount);
					System.out.println("Amount has successfully transferred from account " + customer.getName());
					System.out.println("And now your balance is " + customer.getWallet().getBalance());

				} 
				catch (InvalidInputException e) {
					e.printStackTrace();
				} catch (InsufficientBalanceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				break;
			case 6:
				System.out.println("Enter mobile Number");
				mobileNo = sc.next();
				List<Transactions> transactions = null;
				
				transactions = service.getAllTransactions(mobileNo);
				
				Iterator<Transactions> it = transactions.iterator();
				
				System.out.println("Type \t\tAmount \t\tDate");
				
				while(it.hasNext()) 
				{
					Transactions transaction = it.next();
					System.out.println(transaction.getTransactionType() + "\t" + 
					transaction.getAmount() + "\t" + 
							transaction.getDate() + "\t");
				}
				break;
				
			
			case 0:
				System.out.println("Thank you for using our services");
				System.out.println("Good Bye");
				System.exit(0);
			
			default:
				System.out.println("Please enter valid choice");
				break;
		}
		
		
	}
	
	public static void main(String[] args) 
	{
		Client client = new Client();
		while(true) {
			client.menu();
		}
	}
	
	
}
